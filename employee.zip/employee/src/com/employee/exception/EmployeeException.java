package com.employee.exception;

public class EmployeeException extends Exception {
	String msg;
	public EmployeeException(String msg)
	{
		this.msg=msg;
		
	}
	public String toString() {
		return this.msg;
	}
	

}
