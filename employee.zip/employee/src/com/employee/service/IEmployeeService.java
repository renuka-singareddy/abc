package com.employee.service;

import com.employee.bean.EmployeeBean;
import com.employee.exception.EmployeeException;

public interface IEmployeeService {
	int[] getEmployeeId();

	void employeeSalaryDetails(EmployeeBean bean) throws EmployeeException;

	boolean checkDetails(int empId, String year) throws EmployeeException;

	double calculateTotal(EmployeeBean bean);

	
}
