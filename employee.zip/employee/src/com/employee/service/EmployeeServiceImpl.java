package com.employee.service;

import com.employee.bean.EmployeeBean;
import com.employee.dao.EmployeeDaoImpl;
import com.employee.dao.IEmployeeDao;
import com.employee.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService{
	IEmployeeDao dao=new EmployeeDaoImpl();

	@Override
	public int[] getEmployeeId() {
		
		return dao.getEmployeeId();
	}

	@Override
	public void employeeSalaryDetails(EmployeeBean bean)
			throws EmployeeException {
		dao.employeeSalaryDetails(bean);
		
	}

	@Override
	public boolean checkDetails(int empId,String year) throws EmployeeException {
		return dao.checkDetails(empId, year);
	}

	@Override
	public double calculateTotal(EmployeeBean bean) {
		// TODO Auto-generated method stub
		return (double) ((bean.getBasic()*0.15)-(bean.getHra()*0.15)-(bean.getDa()*0.7));
	}
}

	
