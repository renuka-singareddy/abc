package com.employee.dao;

public interface IQueryMapper {
	String getEmployeeDetailsQuery="select employee_id from employees";
	String employeeSalaryDetailsQuery = "insert into salary values(?,?,?,?,?)";
	String checkDetailsQuery = "select count(*) from salary where employee_id=? and year=?";
}