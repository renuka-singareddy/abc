package com.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.employee.bean.EmployeeBean;
import com.employee.exception.EmployeeException;

public class EmployeeDaoImpl implements IEmployeeDao{

	@Override
	public int[] getEmployeeId() {
		String str=new String("");
		int[] result = null;
		// TODO Auto-generated method stub
		try
		{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			PreparedStatement s=con.prepareStatement(IQueryMapper.getEmployeeDetailsQuery);
			ResultSet rs=s.executeQuery();
			while(rs.next())
			{
			str = str+rs.getInt(1)+"/";
			}
			String[] res=str.split("/");
			int len=res.length;
			result=new int[len];
			for(int i=0;i<len;i++)
			{
				result[i]=Integer.parseInt(res[i]);
			}
		} 
		catch (NamingException | SQLException e) 
		{
			
		}
		return result;
	}


	@Override
	public void employeeSalaryDetails(EmployeeBean bean)
			throws EmployeeException {
		try
		{
		InitialContext ic=new InitialContext();
		DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
		Connection con=ds.getConnection();
		PreparedStatement s=con.prepareStatement(IQueryMapper.employeeSalaryDetailsQuery);
		ResultSet rs=s.executeQuery();
		s.setInt(1,bean.getEmpId());
		s.setString(2,bean.getYear());
		s.setFloat(3,bean.getBasic());
		s.setFloat(4,bean.getHra());
		s.setFloat(5,bean.getDa());
		s.setDouble(6,bean.getTotal());
		s.executeQuery();
	}
		catch(SQLException e)
		{
			throw new EmployeeException("error while inserting data");
		} 
	catch (NamingException e) 
	{
		throw new EmployeeException("error connecting to database");
	}
}

	@Override
	public boolean checkDetails(int empId, String year) throws EmployeeException {
try
{
	InitialContext ic=new InitialContext();
		DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
		Connection con=ds.getConnection();
		PreparedStatement s=con.prepareStatement(IQueryMapper.checkDetailsQuery);
		s.setInt(1, empId);
		s.setString(2, year);
		ResultSet rt=s.executeQuery();
		rt.next();
		int count=rt.getInt(1);
		if(count==0)
		{
			return false;
		}
	}
	catch (NamingException | SQLException e) 
	{
		throw new EmployeeException("error connecting to database");
	}
	return true;
}
}

	