package com.employee.dao;


import com.employee.bean.EmployeeBean;
import com.employee.exception.EmployeeException;

public interface IEmployeeDao {
	int[] getEmployeeId();

	void employeeSalaryDetails(EmployeeBean bean) throws EmployeeException;

	boolean checkDetails(int empId, String year) throws EmployeeException;

	
}
