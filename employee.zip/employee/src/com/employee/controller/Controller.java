package com.employee.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.bean.EmployeeBean;
import com.employee.exception.EmployeeException;
import com.employee.service.EmployeeServiceImpl;
import com.employee.service.IEmployeeService;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("action");
		PrintWriter out=response.getWriter();
		IEmployeeService service=new EmployeeServiceImpl();
		EmployeeBean bean=new EmployeeBean();
		try
		{
			if(operation.equals("getEmployeeId"))
			{
				int[] getEmployeeId=service.getEmployeeId();
				request.setAttribute("employeeId", empId);			
				RequestDispatcher requestDispatcher=request.getRequestDispatcher("/EmployeeSalary.jsp");
				requestDispatcher.forward(request, response);
			}
			else if(operation.equals("addEmployee"))
			{
				bean.setEmpId(Integer.parseInt(request.getParameter("employeeId")));
				bean.setYear(request.getParameter("year"));
				bean.setBasic(Float.parseFloat(request.getParameter("basic")));
				bean.setHra(Float.parseFloat(request.getParameter("hra")));
				bean.setDa(Float.parseFloat(request.getParameter("da")));
				double total=service.calculateTotal(bean);
				bean.setTotal(total);
				if(service.checkDetails(bean.getEmpId(), bean.getYear()))
				{
					int[] empId=service.getEmployeeId();
					request.setAttribute("employeeid", empId);			
					request.setAttribute("error", new EmployeeException("Assessment score with given trainee id and module name already exist"));
					RequestDispatcher requestDispatcher=request.getRequestDispatcher("/AddAssessment.jsp");
					requestDispatcher.forward(request, response);
				}
				else
				{
				service.employeeSalaryDetails(bean);
				request.setAttribute("bean", bean);
				RequestDispatcher requestDispatcher=request.getRequestDispatcher("/ModuleScore.jsp");
				requestDispatcher.forward(request, response);
				}
			}
		}
		catch(EmployeeException e)
		{
			out.print(e.getMessage());
		}
	}
	}
