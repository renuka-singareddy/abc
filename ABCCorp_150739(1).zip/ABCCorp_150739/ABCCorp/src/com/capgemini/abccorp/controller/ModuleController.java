package com.capgemini.abccorp.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.abccorp.bean.ABCCorpBean;
import com.capgemini.abccorp.exception.ABCCorpException;
import com.capgemini.abccorp.service.ABCCorpServiceImpl;
import com.capgemini.abccorp.service.IABCCorpService;

/**
 * Servlet implementation class ModuleController
 */
@WebServlet("/ModuleController")
public class ModuleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModuleController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("action");
		PrintWriter write=response.getWriter();
		IABCCorpService service=new ABCCorpServiceImpl();
		ABCCorpBean bean=new ABCCorpBean();
		try
		{
			if(operation.equals("getTraineeId"))
			{
				int[] traineeId=service.getTraineeId();
				request.setAttribute("traineesid", traineeId);			
				RequestDispatcher requestDispatcher=request.getRequestDispatcher("/AddAssessment.jsp");
				requestDispatcher.forward(request, response);
			}
			else if(operation.equals("addAssessment"))
			{
				bean.setTraineeId(Integer.parseInt(request.getParameter("traineeId")));
				bean.setModuleName(request.getParameter("modulename"));
				bean.setMpt(Integer.parseInt(request.getParameter("mpt")));
				bean.setMtt(Integer.parseInt(request.getParameter("mtt")));
				bean.setAssigment(Integer.parseInt(request.getParameter("assignment")));
				int total=service.calculateTotal(bean);
				bean.setTotal(total);
				int grade=service.calculateGrade(total);
				bean.setGrade(grade);
				if(service.checkDetails(bean.getTraineeId(), bean.getModuleName()))
				{
					int[] traineeId=service.getTraineeId();
					request.setAttribute("traineesid", traineeId);			
					request.setAttribute("error", new ABCCorpException("Assessment score with given trainee id and module name already exist"));
					RequestDispatcher requestDispatcher=request.getRequestDispatcher("/AddAssessment.jsp");
					requestDispatcher.forward(request, response);
				}
				else
				{
				service.addAssessmentDetails(bean);
				request.setAttribute("bean", bean);
				RequestDispatcher requestDispatcher=request.getRequestDispatcher("/ModuleScore.jsp");
				requestDispatcher.forward(request, response);
				}
			}
		}
		catch(ABCCorpException e)
		{
			write.print(e.getMessage());
		}
	}

}
