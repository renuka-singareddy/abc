package com.capgemini.abccorp.dao;

public interface IQueryMapper {
	String getTraineeDetailsQuery="select trainee_id from trainees";
	String addAssessmentDetailsQuery = "insert into assessmentscore values(?,?,?,?,?,?,?)";
	String checkDetailsQuery = "select count(*) from assessmentscore where trainee_id=? and module_name=?";
}
