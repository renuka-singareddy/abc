package com.capgemini.abccorp.dao;

import com.capgemini.abccorp.bean.ABCCorpBean;
import com.capgemini.abccorp.exception.ABCCorpException;

public interface IABCCorpDao {

	int[] getTraineeId();

	void addAssessmentDetails(ABCCorpBean bean) throws ABCCorpException;

	boolean checkDetails(int traineeId, String moduleName) throws ABCCorpException;

}
