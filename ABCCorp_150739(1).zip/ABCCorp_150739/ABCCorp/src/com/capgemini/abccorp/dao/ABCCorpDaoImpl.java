package com.capgemini.abccorp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.abccorp.bean.ABCCorpBean;
import com.capgemini.abccorp.exception.ABCCorpException;

public class ABCCorpDaoImpl implements IABCCorpDao{

	@Override
	public int[] getTraineeId() {
		String str=new String("");
		int[] result = null;
		try
		{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			PreparedStatement s=con.prepareStatement(IQueryMapper.getTraineeDetailsQuery);
			ResultSet rt=s.executeQuery();
			while(rt.next())
			{
				str=str+rt.getInt(1)+"/";
			}
			String[] res=str.split("/");
			int len=res.length;
			result=new int[len];
			for(int i=0;i<len;i++)
			{
				result[i]=Integer.parseInt(res[i]);
			}
		} 
		catch (NamingException | SQLException e) 
		{
			
		}
		return result;
	}

	@Override
	public void addAssessmentDetails(ABCCorpBean bean) throws ABCCorpException {
		try
		{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			PreparedStatement prepareStatement=con.prepareStatement(IQueryMapper.addAssessmentDetailsQuery);
			try
			{
				prepareStatement.setInt(1,bean.getTraineeId());
				prepareStatement.setString(2, bean.getModuleName());
				prepareStatement.setInt(3,bean.getMpt());
				prepareStatement.setInt(4, bean.getMtt());
				prepareStatement.setInt(5, bean.getAssigment());
				prepareStatement.setInt(6, bean.getTotal());
				prepareStatement.setInt(7, bean.getGrade());
				prepareStatement.executeUpdate();
			}
			catch(SQLException e)
			{
				throw new ABCCorpException("error while inserting data");
			}
		} 
		catch (NamingException | SQLException e) 
		{
			throw new ABCCorpException("error connecting to database");
		}
	}

	@Override
	public boolean checkDetails(int traineeId, String moduleName) throws ABCCorpException {
		try
		{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			PreparedStatement s=con.prepareStatement(IQueryMapper.checkDetailsQuery);
			s.setInt(1, traineeId);
			s.setString(2, moduleName);
			ResultSet rt=s.executeQuery();
			rt.next();
			int count=rt.getInt(1);
			if(count==0)
			{
				return false;
			}
		}
		catch (NamingException | SQLException e) 
		{
			throw new ABCCorpException("error connecting to database");
		}
		return true;
	}

}
