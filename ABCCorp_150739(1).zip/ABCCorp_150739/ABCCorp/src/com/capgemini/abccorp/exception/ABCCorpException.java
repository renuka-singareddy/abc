package com.capgemini.abccorp.exception;

public class ABCCorpException extends Exception{
	String msg;
	public ABCCorpException(String msg)
	{
		this.msg=msg;
	}
	public String toString()
	{
		return this.msg;
	}
}
