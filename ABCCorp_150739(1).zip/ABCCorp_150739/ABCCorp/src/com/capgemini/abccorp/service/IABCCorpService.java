package com.capgemini.abccorp.service;

import com.capgemini.abccorp.bean.ABCCorpBean;
import com.capgemini.abccorp.exception.ABCCorpException;

public interface IABCCorpService {

	int[] getTraineeId();

	void addAssessmentDetails(ABCCorpBean bean) throws ABCCorpException;

	int calculateTotal(ABCCorpBean bean);

	int calculateGrade(int total);

	boolean checkDetails(int traineeId, String moduleName) throws ABCCorpException;

}
