package com.capgemini.abccorp.service;

import com.capgemini.abccorp.bean.ABCCorpBean;
import com.capgemini.abccorp.dao.ABCCorpDaoImpl;
import com.capgemini.abccorp.dao.IABCCorpDao;
import com.capgemini.abccorp.exception.ABCCorpException;

public class ABCCorpServiceImpl implements IABCCorpService{
	IABCCorpDao dao=new ABCCorpDaoImpl();
	@Override
	public int[] getTraineeId() {
		return dao.getTraineeId();
	}
	@Override
	public void addAssessmentDetails(ABCCorpBean bean) throws ABCCorpException {
		dao.addAssessmentDetails(bean);
	}
	@Override
	public int calculateTotal(ABCCorpBean bean) {
		return (int) ((bean.getAssigment()*0.15)+(bean.getMtt()*0.15)+(bean.getMpt()*0.7));
	}
	@Override
	public int calculateGrade(int total) {
		int grade;
		if(total<50)
		{
			grade=0;
		}
		else if(total>49 && total<60)
		{
			grade=1;
		}
		else if(total>59 && total<70)
		{
			grade=2;
		}
		else if(total>69 && total<80)
		{
			grade=3;
		}
		else if(total>79 && total<90)
		{
			grade=4;
		}
		else
		{
			grade=5;
		}
		return grade;
	}
	@Override
	public boolean checkDetails(int traineeId, String moduleName) throws ABCCorpException {
		return dao.checkDetails(traineeId,moduleName);
	}

}
